package cn.lyf.controller;

import cn.lyf.dao.domain.User;
import cn.lyf.dao.jdbc.UserDao;
import cn.lyf.dao.xml.UserMapper;
import cn.lyf.service.LoginService;
import com.alibaba.fastjson.JSONArray;
import org.junit.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class LoginController {

//        "userID":"320173826990",
//        "password":"123456Ww",
//        "deviceType":"moblie-ios"

   // LoggerFactory loggerFactory = new LoggerFactory();

    @Autowired
    LoginService loginService;

    @Autowired
    UserDao userDao;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Resource
    UserMapper userMapper;

    @RequestMapping("login")
    @ResponseBody
    public JSONArray login(@RequestParam(name = "userId")String userId,
                           @RequestParam(name = "password")String password,
                           @RequestParam(name = "deviceType")String deviceType){

        System.out.println("userId,password,deviceType:"+userId+","+password+","+deviceType);

        JSONArray jsonArray = new JSONArray();
        //jsonArray = loginService.login(userId,password,deviceType);

        User list = null;

             list=  userDao.queryByUserId(userId);

        System.out.println("userDao:"+userDao.queryByUserId(userId));
        Map<String,Integer> code = new HashMap<>();
        Map<String,String> message = new HashMap<>();
        Map<String, User> result = new HashMap<>();

        // token
        Map<String,String> token = new HashMap<>();
        token.put("token","身份字符串");

        if(list!=null){
            result.put("result",list);
            if(list.getPassword()==password){
                code.put("code",1);
                message.put("message","登陆成功");
            }else{
                code.put("code",0);
                message.put("message","密码错误");
            }
        }else{
            code.put("code",0);
            message.put("message","无该用户ID");
        }

        jsonArray.add(result);
        jsonArray.add(token);
        jsonArray.add(code);
        jsonArray.add(message);

        return jsonArray;
    }

    @RequestMapping(value = "loginTest", method = RequestMethod.POST)
    @ResponseBody
    public void test(@RequestParam(value = "userId") String userId){
      //  System.out.println(userDao.queryByUserId(userId));

        System.out.println("传入参数为"+userId);

        RowMapper<User > user1 = BeanPropertyRowMapper.newInstance(User.class);

        User user = jdbcTemplate.queryForObject("SELECT * FROM user WHERE user_id = '3120031'",user1);

        System.out.println(user);

        System.out.println("测试1。。。");

//        System.out.println(userDao.queryByUserId("2"));
//        System.out.println("测试2。。。");
//        System.out.println(userDao.queryByUserId("3120031"));
//        System.out.println("测试3。。。");


        System.out.println("测试6。。。");
        userMapper.selectByUserId("432");

        System.out.println(userId);
        if(userId=="3120031"){
            System.out.println("yes");
        }else
        {
            System.out.println("no");
        }
        System.out.println("测试4");
        if("3120031".equals(userId)){
            System.out.println("yes1");
        }else{
            System.out.println("no1");
        }



        System.out.println(userDao.queryByUserId((String)userId));

    }


    // 测试JSON
//    JSONArray jsonArray = new JSONArray();
//
//    Map<String,String> message = new HashMap<String,String>();
//
//    Map<String, User> result = new HashMap<String,User>();
//
//    Map<String,String> code = new HashMap<String,String>();
//
//    Map<String,String> token = new HashMap<String,String>();
//
//        message.put("message","登陆成功");
//
//    // https://www.cnblogs.com/telwanggs/p/11200992.html
//    Date date = Date.valueOf("2000-10-21");
//
//        result.put("result",new User(1L,31090132L,"李云飞","123321","学生",19,174.0F,120.1F,date,""));
//
//
//        jsonArray.add(message);
//        jsonArray.add(result);
//        jsonArray.add(code);
//        jsonArray.add(token);
//
//        System.out.println("响应数据为:"+jsonArray);





}
