package cn.lyf.dao.domain;

import java.io.Serializable;
import java.sql.Date;

public class User implements Serializable {

    private Long id;
    private Long userId;
    private String userName;
    private String password;
    private String job;
    private Integer age;
    private Float height;
    private Float weight;
    private Date date;
    private String userPicture;


    public User() {}

    public User(Long id, Long userId, String userName, String password, String job,
                Integer age, Float height, Float weight, Date date, String userPicture) {
        this.id = id;
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.job = job;
        this.age = age;
        this.height = height;
        this.weight = weight;
        this.date = date;
        this.userPicture = userPicture;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public Float getWeight() {
        return weight;
    }

    public void setWeight(Float weight) {
        this.weight = weight;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getUserPicture() {
        return userPicture;
    }

    public void setUserPicture(String userPicture) {
        this.userPicture = userPicture;
    }

    @Override
    public String toString() {
        return "{" +
                " userId=" + userId +
                ", userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", job='" + job + '\'' +
                ", age=" + age +
                ", height=" + height +
                ", weight=" + weight +
                ", date=" + date +
                ", userPicture='" + userPicture + '\'' +
                '}';
    }
}
