package cn.lyf.dao.impl;

import cn.lyf.dao.domain.User;
import cn.lyf.dao.mapper.UserMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserImpl implements UserMapper {
    @Override
    public User queryByUserId(String userId) {
        return null;
    }

    @Override
    public void InsertUser(User user) {

    }

    @Override
    public List<User> queryAll() {
        return null;
    }
}
