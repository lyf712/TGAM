package cn.lyf.dao.jdbc;

import cn.lyf.dao.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class UserDao {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public User queryByUserId(String userId)
    {

//        User[] params= new User[] {};
//
//        String sql ="SELECT * FROM user WHERE user_id = '"+userId+"'";
//
//        List list = jdbcTemplate.queryForList(sql,params);
//
//        if(list.size()==0){
//            return null;
//        }else{
//            return (User)list.get(0);
//        }

        User[] params= new User[] {};



      ///  String userId = "3120031";
        String sql ="SELECT * FROM user WHERE user_id = '"+userId+"'";

        List list = jdbcTemplate.queryForList(sql, new RowMapper<User>() {
                    @Override
                    public User mapRow(ResultSet resultSet, int i) throws SQLException {
                        User user = new User();
                        user.setId(resultSet.getLong(0));
                        user.setUserId(resultSet.getLong(1));
                        user.setUserName(resultSet.getString(2));
                        user.setPassword(resultSet.getString(3));
                        user.setJob(resultSet.getString(4));
                        user.setAge(resultSet.getInt(5));
                        user.setHeight(resultSet.getFloat(6));
                        user.setWeight(resultSet.getFloat(7));
                        user.setDate(resultSet.getDate(8));
                        user.setUserPicture(resultSet.getString(9));
                        return user;
                    }
                }


        );

        //list.get(0).equals(new User())

        User user = new User();
//        list.get(0).equals(user)
        if(list.size()==0){
            System.out.println("不存在");
            return null;
        }else{
            System.out.println(list);
            return (User)list.get(0);
        }

    }





}
