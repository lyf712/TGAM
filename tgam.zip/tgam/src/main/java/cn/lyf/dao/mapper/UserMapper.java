package cn.lyf.dao.mapper;

import cn.lyf.dao.domain.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user WHERE user_id = #{userId}")
    public User queryByUserId(String userId);

    @Insert("INSERT INTO user values(#{id}," +
            "#{userId},'#{userName}','#{password}','#{job}','#{age}','#{height}'," +
            "'#{weight}','#{date}','#{userPicture}')")
    public void InsertUser(User user);

    @Select("SELECT * FROM user")
    public List<User> queryAll();


}
