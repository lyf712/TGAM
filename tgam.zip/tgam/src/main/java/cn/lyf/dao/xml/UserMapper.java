package cn.lyf.dao.xml;

import cn.lyf.dao.domain.User;
import org.springframework.stereotype.Repository;


public interface UserMapper {
    User selectByUserId(String userId);
}
