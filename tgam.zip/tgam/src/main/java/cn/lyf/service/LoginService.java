package cn.lyf.service;

import cn.lyf.dao.impl.UserImpl;
import cn.lyf.dao.mapper.UserMapper;
import com.alibaba.fastjson.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public interface LoginService {

    // 返回响应数据
    JSONArray login(String userId, String password, String deviceType);


}
