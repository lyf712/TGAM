package cn.lyf.service.impl;

import cn.lyf.dao.domain.User;
import cn.lyf.dao.impl.UserImpl;
import cn.lyf.dao.jdbc.UserDao;
import cn.lyf.dao.mapper.UserMapper;
import cn.lyf.service.LoginService;
import com.alibaba.fastjson.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    //UserImpl userDao;
    UserMapper userMapper;

    @Autowired
    UserDao userDao;

    @Override
    public JSONArray login(String userId,String password,String deviceType) {

        JSONArray jsonArray = new JSONArray();

        System.out.println("login service handle login...");
       // System.out.println(userMapper.queryByUserId(userId));
        User user = new User();
        System.out.println("service:"+userId);

        // result 信息
       // user = userMapper.queryByUserId(userId);
        User list =
                userDao.queryByUserId(userId);

        System.out.println("List:"+list);

        Map<String,Integer> code = new HashMap<>();
        Map<String,String> message = new HashMap<>();
        Map<String,User> result = new HashMap<>();

        // token
        Map<String,String> token = new HashMap<>();
        token.put("token","身份字符串");

         if(list!=null){
             result.put("result",list);
             if(user.getPassword()==password){
                 code.put("code",1);
                 message.put("message","登陆成功");
             }else{
                 code.put("code",0);
                 message.put("message","密码错误");
             }
         }else{
            code.put("code",0);
            message.put("message","无该用户ID");
        }

        jsonArray.add(result);
        jsonArray.add(token);
        jsonArray.add(code);
        jsonArray.add(message);

        return jsonArray;
    }
}
