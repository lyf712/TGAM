package cn.example.demo;

import cn.lyf.dao.domain.User;
import cn.lyf.dao.xml.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.annotation.Resource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    UserMapper userMapper;

    @Test
    void contextLoads() {
    }
    @Test
    void testTemplate(){
//        jdbcTemplate.execute("INSERT INTO user values('1'," +
//                "'3120031','吴伟','Ww121','学生','19','179.5','150','2000-9-10','src/main/resources/static')");// linux路径
        //RowMapper<User> rowMapper = null;

//        在spring5.0中使用ParameterizedBeanPropertyRowMapper 时报了错，
//
//        原因：ParameterizedBeanPropertyRowMapper  是spring3.0版本的，在高版本中不适用。
//
//        修改方法：将该变量修改为BeanPropertyRowMapper即可

        RowMapper<User> user1 = BeanPropertyRowMapper.newInstance(User.class);

        String userId = "3120032";

        try{
            User user = jdbcTemplate.queryForObject("SELECT * FROM user WHERE user_id = '"+userId+"'",user1);
            System.out.println(user);
        }catch (EmptyResultDataAccessException e){
             e.printStackTrace();
            System.out.println("无");
        }
    }

    @Test
    void testJdbcTemplate2(){

      ///  RowMapper<User> user1 = BeanPropertyRowMapper.newInstance(User.class);
        User[] params= new User[] {};

        String userId = "3120031";
        String sql ="SELECT * FROM user WHERE user_id = '"+userId+"'";

        List list = jdbcTemplate.queryForList(sql,params);

        if(list.size()==0){
            System.out.println("不存在");
        }else{
            System.out.println(list);
        }

    }


    @Test
    void  test4(){
        userMapper.selectByUserId("33");
    }

}
